import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner mych = new Scanner(System.in);
        int n = mych.nextInt();
        if(n % 2== 0){
            System.out.println("Mahmoud");
        }
        else{
            System.out.println("Ehab");
        }
    }
}

 	  	   	       		  	  	  	