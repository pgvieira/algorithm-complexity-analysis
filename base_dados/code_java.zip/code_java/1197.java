

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()) {
			int n=sc.nextInt();
			if(n%2==0) {
				System.out.println("Mahmoud");
			}else {
				System.out.println("Ehab");
			}
		}
	}
}

		 	  						  			 			   	 		 		